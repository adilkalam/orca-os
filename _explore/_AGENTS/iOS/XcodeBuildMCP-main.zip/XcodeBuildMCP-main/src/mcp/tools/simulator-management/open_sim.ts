// Re-export from simulator to avoid duplication
export { default } from '../simulator/open_sim.ts';
