// Re-export unified tool for macos-project workflow
export { default } from '../project-discovery/show_build_settings.ts';
