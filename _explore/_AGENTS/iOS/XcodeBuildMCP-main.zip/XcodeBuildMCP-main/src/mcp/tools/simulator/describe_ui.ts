// Re-export from ui-testing to avoid duplication
export { default } from '../ui-testing/describe_ui.ts';
