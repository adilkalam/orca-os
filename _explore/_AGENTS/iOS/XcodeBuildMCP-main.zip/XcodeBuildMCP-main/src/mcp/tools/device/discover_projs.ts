// Re-export from project-discovery to complete workflow
export { default } from '../project-discovery/discover_projs.ts';
