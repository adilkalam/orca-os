// Re-export from ui-testing to avoid duplication
export { default } from '../ui-testing/screenshot.ts';
