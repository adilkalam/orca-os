// Re-export from simulator to avoid duplication
export { default } from '../simulator/boot_sim.ts';
