// Re-export from logging to complete workflow
export { default } from '../logging/stop_device_log_cap.ts';
