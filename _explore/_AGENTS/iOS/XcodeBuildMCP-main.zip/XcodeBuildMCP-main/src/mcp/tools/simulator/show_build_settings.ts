// Re-export unified tool for simulator-project workflow
export { default } from '../project-discovery/show_build_settings.ts';
