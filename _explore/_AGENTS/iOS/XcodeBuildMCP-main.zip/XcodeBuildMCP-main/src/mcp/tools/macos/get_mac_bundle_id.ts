// Re-export from project-discovery to complete workflow
export { default } from '../project-discovery/get_mac_bundle_id.ts';
