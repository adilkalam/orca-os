// Re-export from logging to complete workflow
export { default } from '../logging/start_device_log_cap.ts';
