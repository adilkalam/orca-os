export { startLogCapture, stopLogCapture } from '../log_capture.ts';
