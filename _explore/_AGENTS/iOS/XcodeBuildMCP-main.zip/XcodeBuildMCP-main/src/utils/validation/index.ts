/**
 * Focused validation facade.
 * Prefer importing from 'utils/validation/index.js' instead of the legacy utils barrel.
 */
export * from '../validation.ts';
