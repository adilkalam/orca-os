/**
 * Focused logging facade.
 * Prefer importing from 'utils/logging/index.js' instead of the legacy utils barrel.
 */
export { log } from '../logger.ts';
