export {
  startSimulatorVideoCapture,
  stopSimulatorVideoCapture,
  type AxeHelpers,
} from '../video_capture.ts';
